# Transformers for NLP Bachelor Project

This repository contains all the files for the bachelor project on Transformers for Natural Language Processing at the Vrije Universiteit Amsterdam by Ryan Ott.

#### Current State

**Week 1** - Creating a simple sentiment classification model consisting of an embedding layer and a global pooling operation.

The challenge of this week is to get the batching up and running from scratch and testing which global pooling method achieves the highest performance in terms of accuracy.
